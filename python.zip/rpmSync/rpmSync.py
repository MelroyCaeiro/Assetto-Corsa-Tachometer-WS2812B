import os
import sys

import ac
import acsys
import platform
import math
import time

import ac

"""
try:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "dll"))
    sys.path.insert(0, 'apps/python/use_pyserial/serial')
    #ac.console(str(len(sys.path)))
    import serial
    ac.console("Serial pass")
except:
    ac.console("Serial fail")

"""

def serialCheck():
    global arduino
    arduino = serial.Serial(port='COM5', baudrate=115200, timeout=.1)
    #ac.console(data)

try:
    import threading

    sys.path.insert(0, "apps/python/rpmSync/DLLs")
    SYSDIR = "stdlib64" if platform.architecture()[0] == "64bit" else "stdlib"
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), SYSDIR))

    os.environ['PATH'] += ';.'
    import serial
    import serial.tools.list_ports
    ac.console("Serial works")

except Exception as err:
    ac.console("DEMOAPP ERROR: " + str(err))

try:
    serialCheck()
    ac.console("SERIAL CHECK PASS")
except:
    ac.console("SERIAL CHECK FAIL")

appWindow = 0
maxRPMCount = 9000
maxRPM = 9000
currentRPM = 0
RPM = 0
upButton = 0
downButton = 0

# This function gets called by AC when the Plugin is initialised
# The function has to return a string with the plugin name
def acMain(ac_version):
    global appWindow, RPM, maxRPM, maxRPMCount
    appWindow = ac.newApp("rpmSync")
    ac.setSize(appWindow, 200, 150)
    ac.drawBorder(appWindow, 0)
    ac.setBackgroundOpacity(appWindow, 30)
    #ac.setBackgroundTexture(appWindow, "apps/python/rpmSync/gmeterBackground.png")
    RPM = ac.addLabel(appWindow, "RPM: 0")
    ac.setPosition(RPM, 60, 50)

    maxRPM = ac.addLabel(appWindow, "RPM Limit: 9000")
    ac.setPosition(maxRPM, 50, 80)

    upButton = ac.addButton(appWindow, "+")
    ac.setPosition(upButton, 120, 120)
    ac.setSize(upButton, 30, 30)
    ac.setFontSize(upButton, 20)
    ac.addOnClickedListener(upButton, upRPM)

    downButton = ac.addButton(appWindow, "-")
    ac.setPosition(downButton, 50, 120)
    ac.setSize(downButton, 30, 30)
    ac.setFontSize(downButton, 20)
    ac.addOnClickedListener(downButton,downRPM)

    ac.addRenderCallback(appWindow, rpmBar)

    ac.addRenderCallback(appWindow, acUpdate)
    return "rpmSync"

# def testFunc():
# Didn't work bcs no *args
def upRPM(*args):
    global maxRPM, maxRPMCount
    try:
        maxRPMCount+=100
        ac.setText(maxRPM, "RPM Limit: {:.0f}".format(maxRPMCount))
        ac.console(str(maxRPMCount))
    except:
        ac.console("RPM limit increase fail")

def downRPM(*args):
    global maxRPM, maxRPMCount
    try:
        if(maxRPMCount>100):
            maxRPMCount -= 100
            ac.setText(maxRPM, "RPM Limit: {:.0f}".format(maxRPMCount))
            ac.console(str(maxRPMCount))
            #arduino.write("hello")
        else:
            ac.console("RPM cannot be set below 100")
    except:
        ac.console("RPM limit decrease fail")

def rpmBar(*args):
    global maxRPMCount, currentRPM
    try:
        if(currentRPM<=maxRPMCount):
            percentRPM = (currentRPM*100) / (maxRPMCount)
            percentRPM = str(int(percentRPM))
            arduino.write(bytes(percentRPM, 'utf-8'))
            ac.console(str(percentRPM))
        else:
            ac.console("Incorrect RPM limit")
    except:
        ac.console("rpmBar not working")

def acUpdate(deltaT):
    global RPM, currentRPM
    currentRPM = ac.getCarState(0, acsys.CS.RPM)
    ac.setText(RPM, "RPM: {:.0f}".format(currentRPM))

    #ac.log("{} laps completed".format(q))
    #ac.console("{} laps completed".format(q))

def acShutdown():
    percentRPM = "0"
    arduino.write(bytes(percentRPM, 'utf-8'))
    arduino.close()